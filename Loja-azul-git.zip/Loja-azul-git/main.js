const cidade = "são paulo";
const idade = 14;
const nome = "marcos";
console.log("òla " + nome, "voce tem " + idade, " e voce mora em " + cidade);